#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"

#include <iostream>
#include <stdio.h>

using namespace std;
using namespace cv;

/** Function Headers */
void detectAndDisplay( Mat frame );

/** Global variables */
String mouth_cascade_name = "haarcascade_frontalface_alt.xml";
CascadeClassifier mouth_cascade;

String window_name = "Capture - Face detection";

/** @function main */
int main( void )
{
    VideoCapture capture;
    Mat frame;

    //-- 1. Load the cascades
    if( !mouth_cascade.load( mouth_cascade_name ) ){ printf("--(!)Error loading face cascade\n"); return -1; };
  
    //-- 2. Read the video stream
    capture.open( -1 );
    if ( ! capture.isOpened() ) { printf("--(!)Error opening video capture\n"); return -1; }

    while ( capture.read(frame) )
    {
        if( frame.empty() )
        {
            printf(" --(!) No captured frame -- Break!");
            break;
        }

        //-- 3. Apply the classifier to the frame
        detectAndDisplay( frame );

        int c = waitKey(10);
        if( (char)c == 27 ) { break; } // escape
    }
    return 0;
}

/** @function detectAndDisplay */
void detectAndDisplay( Mat frame )
{
    std::vector<Rect> mouth;
    Mat frame_gray;

    cvtColor( frame, frame_gray, COLOR_BGR2GRAY );
    equalizeHist( frame_gray, frame_gray );

    //-- Detect faces
    mouth_cascade.detectMultiScale( frame_gray, mouth, 1.1, 2, 0|CASCADE_SCALE_IMAGE, Size(30, 30) );

    for ( size_t i = 0; i < mouth.size(); i++ )
    {
         Point center( mouth[i].x + mouth[i].width/2, mouth[i].y + mouth[i].height/2 );
         ellipse( frame, center, Size( mouth[i].width/2, mouth[i].height/2 ), 0, 0, 360, Scalar( 255, 0, 0 ), 2, 8, 0 );

        Mat faceROI = frame_gray( mouth[i] );
        std::vector<Rect> mouth;

        
    }
    //-- Show what you got
    imshow( window_name, frame );
}
